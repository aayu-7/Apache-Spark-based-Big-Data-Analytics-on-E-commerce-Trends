import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import time
from spark_backend.spark_processor import SparkProcessor
from google.generativeai import GenerativeModel
import google.generativeai as genai
import tempfile
import os

from fpdf import FPDF

# Initialize Gemini model
GEMINI_API_KEY = "AIzaSyDqKDfgPfMx2ZWyqHXTuJf1z62AioZthMI"  # Replace with your Gemini API Key
genai.configure(api_key=GEMINI_API_KEY)
model = GenerativeModel("gemini-1.5-pro")

# Page configuration
st.set_page_config(page_title="E-commerce Trends Analytics", layout="wide")

# Theme toggle
theme = st.sidebar.radio("🌗 Choose Theme", ["Light", "Dark"])
if theme == "Dark":
    st.markdown("""
        <style>
        html, body, .stApp {
            background-color: #121212;
            color: #ffffff;
        }
        .css-1d391kg, .css-18e3th9 {
            background-color: #1e1e1e;
        }
        h1, h2, h3, h4, h5, h6 {
            color: #00BFFF;
        }
        </style>
    """, unsafe_allow_html=True)
else:
    st.markdown("""
        <style>
        html, body, .stApp {
            background-color: #ffffff;
            color: #000000;
        }
        .css-1d391kg, .css-18e3th9 {
            background-color: #f7f9fc;
        }
        h1, h2, h3, h4, h5, h6 {
            color: #2E86C1;
        }
        </style>
    """, unsafe_allow_html=True)

# Header
st.markdown("<h1>E-commerce Trends Analytics Dashboard</h1>", unsafe_allow_html=True)

# Sidebar info
st.sidebar.image("https://cdn-icons-png.flaticon.com/512/2798/2798007.png", width=100)
st.sidebar.markdown("### Upload your Dataset and Explore Trends 🚀")

# File uploader
uploaded_file = st.file_uploader("📁 Upload your E-commerce dataset", type=["csv", "parquet"])

# Initialize Spark session
sp = SparkProcessor()
df = None

if uploaded_file is not None:
    with st.spinner("Reading file with Spark..."):
        temp_file_path = "temp_data.csv"
        with open(temp_file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        df = sp.read_csv(temp_file_path)

        if df is not None:
            df_pd = df.toPandas()
            st.success("✅ File loaded successfully!")
            st.write("### 📊 Preview of Data")
            st.dataframe(df_pd.head(10))
        else:
            st.error("❌ Failed to read the file with Spark.")

    # Data cleaning options
    with st.expander("⚙️ Data Preprocessing Options"):
        if st.checkbox("Drop rows with missing values"):
            df_pd.dropna(inplace=True)
            st.success("🧹 Null values dropped!")

    # Column selection for analysis
    col1 = st.selectbox("Select Column 1", df_pd.columns)
    col2 = st.selectbox("Select Column 2", df_pd.columns)

    # Suggested chart type
    with st.expander("📊 Suggested Chart Types"):
        if df_pd[col1].dtype == 'object' and pd.api.types.is_numeric_dtype(df_pd[col2]):
            st.info("Recommended: Bar Chart or Pie Chart")
        elif pd.api.types.is_numeric_dtype(df_pd[col1]) and pd.api.types.is_numeric_dtype(df_pd[col2]):
            st.info("Recommended: Scatter Plot or Line Chart")

    # Chart generation with progress bar
    st.write("### 📈 Generate Graph")
    if st.button("Generate Chart"):
        with st.spinner("Generating chart..."):
            progress = st.progress(0)
            for i in range(100):
                time.sleep(0.01)
                progress.progress(i + 1)

            fig, ax = plt.subplots()
            if pd.api.types.is_numeric_dtype(df_pd[col1]) and pd.api.types.is_numeric_dtype(df_pd[col2]):
                sns.scatterplot(data=df_pd, x=col1, y=col2, ax=ax)
            else:
                sns.barplot(data=df_pd, x=col1, y=col2, ax=ax)

            st.pyplot(fig)

            # Save figure in session state for PDF export
            st.session_state.fig = fig

            # AI insight generation
            with st.spinner("💡 Generating insights using Gemini..."):
                sample_data = df_pd[[col1, col2]].head().to_string()
                prompt = f"Give insights about the relationship between {col1} and {col2} in this data:\n{sample_data}"
                try:
                    response = model.generate_content(prompt)
                    insight_text = response.text
                    st.success("✨ Insight generated successfully")
                    st.write(insight_text)
                    st.session_state.insight_text = insight_text
                except Exception as e:
                    st.error("Gemini API error: " + str(e))

    # Correlation heatmap
    with st.expander("📌 Correlation Matrix"):
        numeric_df = df_pd.select_dtypes(include=['float64', 'int64'])
        fig_corr, ax_corr = plt.subplots(figsize=(10, 6))
        sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", ax=ax_corr)
        st.pyplot(fig_corr)

    # More visuals
    with st.expander("📦 Additional Visualizations"):
        st.write("#### 🔺 Top Categories by Sales (Example)")
        if 'Category' in df_pd.columns and 'Sales' in df_pd.columns:
            top_categories = df_pd.groupby('Category')['Sales'].sum().sort_values(ascending=False).head(5)
            st.bar_chart(top_categories)

        st.write("#### 📤 Upload Frequency by Month (Example)")
        if 'Order Date' in df_pd.columns:
            df_pd['Order Date'] = pd.to_datetime(df_pd['Order Date'], errors='coerce')
            monthly_orders = df_pd['Order Date'].dt.to_period('M').value_counts().sort_index()
            st.line_chart(monthly_orders)

    # Downloadable report as CSV
    st.download_button(
        label="📥 Download Cleaned Data (CSV)",
        data=df_pd.to_csv(index=False).encode('utf-8'),
        file_name="cleaned_data.csv",
        mime="text/csv"
    )

    # Export to PDF
    if st.button("🧾 Export Report to PDF"):
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", "B", 16)
        pdf.cell(0, 10, "E-commerce Trends Analytics Report", ln=True, align='C')
        pdf.ln(10)

        # Add some text summary (first 5 rows of few columns)
        for col in df_pd.columns[:5]:
            values = df_pd[col].astype(str).head(5).tolist()
            pdf.set_font("Arial", size=12)
            pdf.multi_cell(0, 10, f"{col}: {', '.join(values)}")
            pdf.ln(2)

        # Add AI insights if available
        if 'insight_text' in st.session_state:
            pdf.set_font("Arial", "I", 12)
            pdf.ln(5)
            pdf.multi_cell(0, 10, "AI-Generated Insights:")
            pdf.set_font("Arial", size=12)
            pdf.multi_cell(0, 10, st.session_state.insight_text)
            pdf.ln(10)

        # Add the chart image if available
        if 'fig' in st.session_state:
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmpfile:
                st.session_state.fig.savefig(tmpfile.name, bbox_inches='tight')
                tmpfile_path = tmpfile.name

            pdf.image(tmpfile_path, x=10, w=pdf.w - 20)  # width with margins

            # Clean up temp file
            os.remove(tmpfile_path)

        # Get PDF as bytes
        pdf_bytes = pdf.output(dest='S').encode('latin1')

        st.download_button(
            label="📄 Download PDF Report",
            data=pdf_bytes,
            file_name="ecommerce_report.pdf",
            mime="application/pdf"
        )

else:
    st.info("👈 Please upload a CSV or Parquet file to begin.")
