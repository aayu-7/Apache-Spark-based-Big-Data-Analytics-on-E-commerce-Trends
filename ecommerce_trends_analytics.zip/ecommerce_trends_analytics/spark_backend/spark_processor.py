from pyspark.sql import SparkSession

class SparkProcessor:
    def __init__(self):
        self.spark = SparkSession.builder \
            .appName("EcommerceTrends") \
            .getOrCreate()

    def read_csv(self, file_path, infer_schema=True, header=True):
        df = self.spark.read.csv(file_path, inferSchema=infer_schema, header=header)
        return df  # ✅ Make sure this line exists
